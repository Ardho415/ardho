from flask import Flask, request, render_template, send_from_directory, redirect, url_for
import numpy as np
from PIL import Image
import os

app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
COMPRESSED_FOLDER = 'compressed'

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(COMPRESSED_FOLDER, exist_ok=True)

def compress_image_svd(image_path, compression_rate):
    image = Image.open(image_path).convert('RGB')
    img_array = np.array(image)

    compressed_channels = []
    for i in range(3):  # Iterate over the R, G, B channels
        channel = img_array[:, :, i]
        U, S, Vt = np.linalg.svd(channel, full_matrices=False)
        k = int(min(U.shape[0], Vt.shape[0]) * (compression_rate / 100))
        compressed_channel = np.dot(U[:, :k], np.dot(np.diag(S[:k]), Vt[:k, :]))
        compressed_channels.append(compressed_channel)

    compressed_img_array = np.stack(compressed_channels, axis=2).astype(np.uint8)
    compressed_image = Image.fromarray(compressed_img_array)
    compressed_image_path = os.path.join(COMPRESSED_FOLDER, 'compressed.jpg')
    compressed_image.save(compressed_image_path)
    return compressed_image_path

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        if 'file' not in request.files:
            return 'No file part'
        file = request.files['file']
        if file.filename == '':
            return 'No selected file'
        if file:
            file_path = os.path.join(UPLOAD_FOLDER, file.filename)
            file.save(file_path)
            compression_rate = float(request.form['compression_rate'])
            compressed_image_path = compress_image_svd(file_path, compression_rate)
            return render_template('index.html', 
                                   original_image=file.filename, 
                                   compressed_image='compressed.jpg',
                                   original_size=os.path.getsize(file_path),
                                   compressed_size=os.path.getsize(compressed_image_path))
    return render_template('index.html')

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(UPLOAD_FOLDER, filename)

@app.route('/compressed/<filename>')
def compressed_file(filename):
    return send_from_directory(COMPRESSED_FOLDER, filename)

if __name__ == '__main__':
    app.run(debug=True)
